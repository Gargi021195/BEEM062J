function changeImage(){
var image = document.getElementById('myImage');

if

(image.src.match("Bitcoin_2"))

{image.src="Bitcoin_1.jpg";}

else
{image.src="Bitcoin_2.jpg";}

}